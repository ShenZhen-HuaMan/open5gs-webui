#!/bin/bash
echo "Enter" | sudo  nohup add-apt-repository ppa:open5gs/latest >/dev/null 2>&1 &
sleep 20
nohup sudo apt update >/dev/null 2>&1 &
sleep 20
nohup sudo apt install open5gs >/dev/null 2>&1 &
sleep 20
nohup sudo systemctl restart open5gs-* >/dev/null 2>&1 &



