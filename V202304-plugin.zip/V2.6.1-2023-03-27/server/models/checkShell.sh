#!/bin/bash


function open5gs_service_check()
{
    result1=`systemctl is-active open5gs-amfd.service`
    result2=`systemctl is-active open5gs-hssd.service`
    result3=`systemctl is-active open5gs-scpd.service`
    result4=`systemctl is-active open5gs-smfd.service`
    result5=`systemctl is-active open5gs-upfd.service`
    result6=`systemctl is-active open5gs-ausfd.service`
    result7=`systemctl is-active open5gs-mmed.service`
    result8=`systemctl is-active open5gs-pcfd.service`
    result9=`systemctl is-active open5gs-sgwcd.service`
    result10=`systemctl is-active open5gs-udmd.service`
    result11=`systemctl is-active open5gs-webui.service`
    result12=`systemctl is-active open5gs-bsfd.service `
    result13=`systemctl is-active open5gs-nrfd.service`
    result14=`systemctl is-active open5gs-pcrfd.service`
    result15=`systemctl is-active open5gs-sgwud.service`
    result16=`systemctl is-active open5gs-udrd.service`
    result17=`systemctl is-active open5gs-nssfd.service`
    result18=`systemctl is-active mongod.service`
    # result: active or inactive
    if [[ $result1 = "active" && $result2 = "active" && $result3 = "active" &&
    $result4 = "active" && $result5 = "active" && $result6 = "active" &&
    $result7 = "active" && $result8 = "active" &&$result9 = "active" &&
    $result10 = "active" && $result11 = "active" && $result12 = "active" &&
    $result13 = "active" && $result14 = "active" && $result15 = "active" &&
    $result16 = "active" && $result17 = "active" && $result18 = "active" ]]; then
        echo "active"
        exit
    fi

    echo "inactive"
    # echo "[-] Restart now"
    # sudo systemctl restart mysql
    # echo "[-] Done!"
}


function main()
{
    open5gs_service_check

}



main



