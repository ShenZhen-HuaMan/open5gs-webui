const express = require('express');
const router = express.Router();
const child_process = require('child_process');
// const { stdout, stderr } = require('process');


router.get('/execute2', (req, res) => {
  console.log("execute2 success")
  
  var result
  // var child = child_process.spawn('sudo' && 'sh',['../models/UpgradeShell.sh']);
  child_process.exec("bash /home/2023-03-11/open5gs-2.6.1/open5gs/server/models/checkShell.sh",{},(err,stdout,stderr)=>{
    if (err) {
      console.error(`exec error: ${err}`);
      return;
    }
    // console.log(err,stdout,stderr);
    // console.log(`${stdout}`);
    // console.log(`${stderr}`);
    result = stdout;
    // return res.json({data:result});
  //  var  result2 = result.replace(/[]/g,"");

   if(result == "active\n"){
      return res.json({data:'true'});
    }else{
      return res.json({data:'false'});
    }


    console.error(`stderr: ${stderr}`);
 });

    // child.stdout.on('data', function(data) {
    //   console.log("helloo==",data);
    // });
    // console.log(`Number of files ${stdout}`);
    
    // return res.json({data:"success===!"});
    // return res.json({data:"${stdout}"});
    // return res.send(`${stdout}`);
  // return  result;
  
  

});
  
  // return new Promise((resolve,reject)=>{
  //     var child = child_process.spawn('sudo' && 'sh',['../models/UpgradeShell.sh']);
  //   child.stdout.on('data', function(data) {
  //     console.log("helloo==",data);
  //     resolve(data);
  //   });

  //   child.on('error', function(e) {
  //     console.log("error==",e);
  //     reject(e);
  //   });
  //   })



  //   child.stdout.on('data', function(data) {
  //   console.log("checkStatus",data);
  //  });
  // return res.json({data:"success===!"});
  // console.log(`${stdout}`);
// })


module.exports = router;