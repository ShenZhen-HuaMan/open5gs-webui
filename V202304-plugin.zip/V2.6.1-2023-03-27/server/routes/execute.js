const express = require('express');
const router = express.Router();
const child_process = require('child_process');


  

   function execute(){
    child_process.exec("sh /home/2023-03-11/open5gs-2.6.1/open5gs/server/models/UpgradeShell.sh",{},(err,stdout,stderr)=>{
      console.log(err,stdout,stderr);
    })
    // return new Promise((resolve,reject)=>{
    //   var child = child_process.spawn('sudo' && 'sh',['../models/UpgradeShell.sh']);
    // child.stdout.on('data', function(data) {
    //   console.log("helloo==",data);
    //   resolve(data);
    // });

    // child.on('error', function(e) {
    //   console.log("error==",e);
    //   reject(e);
    // });
    // })
    
  }
  // setTimeout(() => {
      execute();
  // }, 5000);



  



  

// const Subscriber = require('../models/subscriber');
// restify.serve(router, Subscriber, {
//   prefix: '',
//   version: '',
//   idProperty: 'imsi'
// });

// const Profile = require('../models/profile');
// restify.serve(router, Profile, {
//   prefix: '',
//   version: ''
// });

// const Account = require('../models/account');
// restify.serve(router, Account, {
//   prefix: '',
//   version: '',
//   idProperty: 'username'
// });


module.exports = router;