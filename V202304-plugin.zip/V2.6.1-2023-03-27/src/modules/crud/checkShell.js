import {
  // fetchCollection,
  // fetchDocument,
  // createDocument,
  // updateDocument,
  // deleteDocument,
  checkShellCollection
} from './actions'

export const MODEL = 'checkShells';
export const URL = '/checkShell';

// export const fetchUpgrades = (params = {}) => {
//   return fetchCollection(MODEL, URL, params);
// }

// export const fetchUpgrade = (_id, params = {}) => {
//   return fetchDocument(MODEL, _id, `${URL}/${_id}`, params);
// }

// export const createUpgrade = (params = {}, data = {}) => {
//   return createDocument(MODEL, URL, params, data);
// }

export const checkShell = async () => {
  console.log("checkShell");
  return await fetch("/api/checkShell/execute2").then(function(response){
    if(response.status===200){
      return response.json();
      console.log(response.json());
      // console.log(response);
    }else{
      return {}
    }
  })
  //return checkShellCollection(MODEL, URL);
}

// export const updateUpgrade = (_id, params = {}, data = {}) => {
//   return updateDocument(MODEL, _id, `${URL}/${_id}`, params, data);
// }

// export const deleteUpgrade = (_id, params = {}) => {
//   return deleteDocument(MODEL, _id, `${URL}/${_id}`, params);
// }
