import {
  // fetchCollection,
  // fetchDocument,
  // createDocument,
  // updateDocument,
  // deleteDocument,
  upgradeShellDocument
} from './actions'

export const MODEL = 'upgradeShells';
export const URL = '/upgradeShell';

// export const fetchUpgrades = (params = {}) => {
//   return fetchCollection(MODEL, URL, params);
// }

// export const fetchUpgrade = (_id, params = {}) => {
//   return fetchDocument(MODEL, _id, `${URL}/${_id}`, params);
// }

// export const createUpgrade = (params = {}, data = {}) => {
//   return createDocument(MODEL, URL, params, data);
// }

export const upgradeShell = () => {
  console.log("upgradeShell");
  fetch("/api/upgradeShell/execute").then(function(response){
    if(response.status===200){
      return response.json();
    }else{
      return {}
    }
  })
  return upgradeShellDocument(MODEL, URL);
}

// export const updateUpgrade = (_id, params = {}, data = {}) => {
//   return updateDocument(MODEL, _id, `${URL}/${_id}`, params, data);
// }

// export const deleteUpgrade = (_id, params = {}) => {
//   return deleteDocument(MODEL, _id, `${URL}/${_id}`, params);
// }
