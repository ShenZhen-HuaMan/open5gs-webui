import {
  fetchCollection,
  fetchDocument,
  createDocument,
  updateDocument,
  deleteDocument,
  upgradeShellDocument
} from './actions'

export const MODEL = 'upgrades';
export const URL = '/Upgrade';

export const fetchUpgrades = (params = {}) => {
  return fetchCollection(MODEL, URL, params);
}

export const fetchUpgrade = (_id, params = {}) => {
  return fetchDocument(MODEL, _id, `${URL}/${_id}`, params);
}

export const createUpgrade = (params = {}, data = {}) => {
  return createDocument(MODEL, URL, params, data);
}

export const upgradeShell = (params = {}) => {
  return upgradeShellDocument(MODEL, URL, params);
}

export const updateUpgrade = (_id, params = {}, data = {}) => {
  return updateDocument(MODEL, _id, `${URL}/${_id}`, params, data);
}

export const deleteUpgrade = (_id, params = {}) => {
  return deleteDocument(MODEL, _id, `${URL}/${_id}`, params);
}
