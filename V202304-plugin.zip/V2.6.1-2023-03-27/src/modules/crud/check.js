import {
  fetchCollection,
  fetchDocument,
  createDocument,
  updateDocument,
  deleteDocument,
  // statusShellDocument
} from './actions'

export const MODEL = 'checks';
export const URL = '/Check';

export const fetchChecks = (params = {}) => {
  return fetchCollection(MODEL, URL, params);
}

export const fetchCheck = (_id, params = {}) => {
  return fetchDocument(MODEL, _id, `${URL}/${_id}`, params);
}

export const createCheck = (params = {}, data = {}) => {
  return createDocument(MODEL, URL, params, data);
}

// export const statusShell = (params = {}) => {
//   return statusShellDocument(MODEL, URL, params);
// }

export const updateCheck = (_id, params = {}, data = {}) => {
  return updateDocument(MODEL, _id, `${URL}/${_id}`, params, data);
}

export const deleteCheck = (_id, params = {}) => {
  return deleteDocument(MODEL, _id, `${URL}/${_id}`, params);
}
