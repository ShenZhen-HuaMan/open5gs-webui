import { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import { MODEL, fetchChecks, deleteCheck } from 'modules/crud/check';
import { clearActionStatus } from 'modules/crud/actions';
import { select, selectActionStatus } from 'modules/crud/selectors';
import {checkShell} from 'modules/crud/checkShell';
import * as Notification from 'modules/notification/actions';
import {BlankCheck1,BlankCheck2} from 'components';

import { 
  Layout, 
  Check, 
  Spinner, 
  FloatingButton, 
  Dimmed,
  Confirm
} from 'components';

import Document from './Document';

class Collection extends Component {
  state = {
    document: {
      action: '',
      visible: false,
      dimmed: false
    },
    confirm: {
      visible: false,
      _id: ''
    },
    view: {
      visible: false,
      disableOnClickOutside: false,
      _id: ''
    },
    checkStatus:{}
  };

  componentWillMount() {
    const { checks, dispatch } = this.props
   

    if (checks.needsFetch) {
      dispatch(checks.fetch)
    }
    this.executeshell();
  }

  async executeshell(){
    const res  = await checkShell(); 
    console.log("checkStatus",res);
    this.setState({
      checkStatus:res
    })
  }

  componentWillReceiveProps(nextProps) {
    const { checks, status } = nextProps
    const { dispatch } = this.props

    if (checks.needsFetch) {
      dispatch(checks.fetch)
    }

    if (status.response) {
      dispatch(Notification.success({
        title: 'Status',
//        message: `${status.id} has been deleted`
        message: `This status has been deleted`
      }));
      dispatch(clearActionStatus(MODEL, 'delete'));
    } 

    if (status.error) {
      let title = 'Unknown Code';
      let message = 'Unknown Error';
      if (response.data && response.data.name && response.data.message) {
        title = response.data.name;
        message = response.data.message;
      } else {
        title = response.status;
        message = response.statusText;
      }

      dispatch(Notification.error({
        title,
        message,
        autoDismiss: 0,
        action: {
          label: 'Dismiss'
        }
      }));
      dispatch(clearActionStatus(MODEL, 'delete'));
    }
  }

  documentHandler = {
    show: (action, payload) => {
      this.setState({
        document: {
          action,
          visible: true,
          dimmed: true,
          ...payload
        },
        view: {
          ...this.state.view,
          disableOnClickOutside: true
        }
      })
    },
    hide: () => {
      this.setState({
        document: {
          action: '',
          visible: false,
          dimmed: false
        },
        view: {
          ...this.state.view,
          disableOnClickOutside: false
        }
      })
    },
    actions: {
      create: () => {
        this.documentHandler.show('create');
      },
      update: (_id) => {
        this.documentHandler.show('update', { _id });
      }
    }
  }

  confirmHandler = {
    show: (_id) => {
      this.setState({
        confirm: {
          visible: true,
          _id,
        },
        view: {
          ...this.state.view,
          disableOnClickOutside: true
        }
      })
    },
    hide: () => {
      this.setState({
        confirm: {
          ...this.state.confirm,
          visible: false
        },
        view: {
          ...this.state.view,
          disableOnClickOutside: false
        }
      })
    },
    actions : {
      delete: () => {
        const { dispatch } = this.props

        if (this.state.confirm.visible === true) {
          this.confirmHandler.hide();
          this.documentHandler.hide();
          this.viewHandler.hide();

          dispatch(deleteStatus(this.state.confirm._id));
        }
      }
    }
  }

  viewHandler = {
    show: (_id) => {
      this.setState({
        view: {
          _id,
          visible: true,
          disableOnClickOutside: false
        }
      });
    },
    hide: () => {
      this.setState({
        view: {
          ...this.state.view,
          visible: false
        }
      })
    }
  }


  render() {
    const {
      documentHandler,
      viewHandler,
      confirmHandler
    } = this;

    const { 
      document,
      checkStatus
    } = this.state;

    const { 
      checks,
      status,
      dispatch
    } = this.props

    const {
      isLoading,
      data
    } = checks;

    
    // .then(res =>{
      
    //   setTimeout(() => {
    //     // NProgress.done(true);
    //     console.log(res);
    //   }, 1000*1*60);

    // });



  console.log(checkStatus);

  if(JSON.stringify(checkStatus)==`{}`){
    return <div></div>
  }

    if(JSON.stringify(checkStatus)==`{"data":"true"}`){
      return (
        <Layout.Content>
          {isLoading && <Spinner md />}
          <BlankCheck1
            visible={!isLoading && !(Object.keys(data).length > 0)}
            body="Your system is working fine."
          /> 
        </Layout.Content>
      )
     }else {
      return (
        <Layout.Content>
          {isLoading && <Spinner md />}
          <BlankCheck2
            visible={!isLoading && !(Object.keys(data).length > 0)}
            body="Your system is not working correctly!"
          /> 
        </Layout.Content>
      )
     }
  //  }

  //  )
   

   

    // return (
      
    //   <Layout.Content>
    //     {isLoading && <Spinner md />}
    //     <BlankCheck2
    //       visible={!isLoading && !(Object.keys(data).length > 0)}
    //       body="Your system is not working correctly!"
    //     /> 
    //   </Layout.Content>
    // )
  }
}

Collection = connect(
  (state) => ({ 
    checks: select(fetchChecks(), state.crud),
    status: selectActionStatus(MODEL, state.crud, 'delete')
  })
)(Collection);

export default Collection;
