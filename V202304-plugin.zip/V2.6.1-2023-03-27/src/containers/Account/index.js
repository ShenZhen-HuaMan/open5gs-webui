import Collection from './Collection';
import Document from './Document';

export {
  Collection,
  Document
};